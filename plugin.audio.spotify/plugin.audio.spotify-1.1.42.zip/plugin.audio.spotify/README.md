# plugin.audio.spotify
Unofficial spotify plugin for Kodi


Install the add-on from my Kodi repo:
https://github.com/marcelveldt/repository.marcelveldt/raw/master/repository.marcelveldt/repository.marcelveldt-1.0.1.zip


Support is provided on the Kodi forums:
http://forum.kodi.tv/showthread.php?tid=265356